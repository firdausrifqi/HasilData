class Question:
    def __init__(self, item, label):
        self.item= item
        self.label=label
        
       
